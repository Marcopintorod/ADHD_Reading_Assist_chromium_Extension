// ========================================================
// Scroll Word Reader - Viewer Logic (PDF & Word DOCX)
// Compatible con Manifest V3 y estricto CSP de Chromium
// ========================================================

import * as pdfjsLib from './libs/pdf.min.mjs';

// Configurar Worker de PDF.js de forma compatible con Manifest V3 y extensiones locales
try {
  const workerUrl = (typeof chrome !== 'undefined' && chrome.runtime?.getURL)
    ? chrome.runtime.getURL('libs/pdf.worker.min.mjs')
    : './libs/pdf.worker.min.mjs';
  pdfjsLib.GlobalWorkerOptions.workerSrc = workerUrl;
} catch (err) {
  console.warn('[SWR Viewer] Fallback a workerSrc relativo:', err);
  pdfjsLib.GlobalWorkerOptions.workerSrc = './libs/pdf.worker.min.mjs';
}

// Configuración predeterminada sincronizada con la extensión
const DEFAULTS = {
  language: 'es',
  scrollMode: 'natural',
  enabled: false,
  colorHighlight: true,
  bionicBold: false,
  bionicUpper: false,
  bionicAmount: 1,
  color: '#ffeb3b',
  wordCount: 1,
  sensitivity: 50,
  tunnelEnabled: false,
  tunnelSize: 180,
  tunnelBlur: 8,
  beelineEnabled: false,
  beelineColor1: '#2563eb',
  beelineColor2: '#dc2626',
  beelineIntensity: 60,
  celebrateEnabled: true,
  celebrateStep: 25
};

let config = { ...DEFAULTS };

const I18N = {
  es: {
    noDocLoaded: 'Sin documento cargado',
    loadFileBtn: 'Cargar Archivo',
    readerOnBtn: 'Modo Lectura: ON',
    readerOffBtn: 'Modo Lectura: OFF',
    dropTitle: 'Arrastra tu archivo PDF o Word (.docx) aquí',
    dropSubtitle: 'O haz clic para seleccionarlo de tu ordenador. El texto será procesado localmente con formato editorial optimizado para lectura asistida por scroll.',
    clickFocusPill: 'Clic para mover foco',
    toastReaderOn: 'Modo lectura: Activado',
    toastReaderOff: 'Modo lectura: Desactivado',
    toastColorOn: 'Recorrido con color: Activado',
    toastColorOff: 'Recorrido con color: Desactivado',
    milestone: (step) => `🎉 ¡Felicitaciones! Has completado el ${step}% del texto`,
    wordProgress: (cur, total, pct) => `Palabra ${cur.toLocaleString()} de ${total.toLocaleString()} (${pct}%)`,
    zeroProgress: 'Palabra 0 de 0 (0%)'
  },
  en: {
    noDocLoaded: 'No document loaded',
    loadFileBtn: 'Load File',
    readerOnBtn: 'Reading Mode: ON',
    readerOffBtn: 'Reading Mode: OFF',
    dropTitle: 'Drop your PDF or Word (.docx) file here',
    dropSubtitle: 'Or click to select from your computer. Text will be processed locally with editorial format optimized for scroll reading.',
    clickFocusPill: 'Click to shift focus',
    toastReaderOn: 'Reading mode: Enabled',
    toastReaderOff: 'Reading mode: Disabled',
    toastColorOn: 'Color trail: Enabled',
    toastColorOff: 'Color trail: Disabled',
    milestone: (step) => `🎉 Congratulations! You have completed ${step}% of the text`,
    wordProgress: (cur, total, pct) => `Word ${cur.toLocaleString()} of ${total.toLocaleString()} (${pct}%)`,
    zeroProgress: 'Word 0 of 0 (0%)'
  }
};

function getViewerDict() {
  return I18N[config.language === 'en' ? 'en' : 'es'] || I18N.es;
}

function applyViewerTranslations() {
  const dict = getViewerDict();
  document.querySelectorAll('[data-i18n]').forEach((el) => {
    const key = el.getAttribute('data-i18n');
    if (dict[key]) {
      el.textContent = dict[key];
    }
  });
}

// Aplicar clases visuales dinámicas de Bionic Reading
function applyBionicClasses() {
  if (document.body) {
    document.body.classList.toggle('swr-bionic-bold', Boolean(config.bionicBold));
    document.body.classList.toggle('swr-bionic-upper', Boolean(config.bionicUpper));
  }
}

// Estado interno del lector
let words = [];
let currentIndex = 0;
let scrollAccumulator = 0;
let lastHighlightedWords = [];
let toastTimeout = null;
let lastCelebratedMilestone = 0;
let beelineApplied = false;

// Referencias a elementos del DOM
const dropZone = document.getElementById('dropZone');
const fileInput = document.getElementById('fileInput');
const btnSelectFile = document.getElementById('btnSelectFile');
const documentWrapper = document.getElementById('documentWrapper');
const viewerContent = document.getElementById('viewerContent');
const docNameEl = document.getElementById('docName');
const docProgressEl = document.getElementById('docProgress');
const progressBarEl = document.getElementById('readingProgressBar');
const btnToggleReader = document.getElementById('btnToggleReader');
const floatingBtn = document.getElementById('swr-floating-btn');
const loadingOverlay = document.getElementById('loadingOverlay');
const loadingText = document.getElementById('loadingText');
const toastEl = document.getElementById('swr-toast');

// ========================================================
// 1. Sincronización con chrome.storage.sync y almacenamiento local
// ========================================================

if (typeof chrome !== 'undefined' && chrome.storage?.sync) {
  // Cargar configuración inicial guardada
  chrome.storage.sync.get(DEFAULTS, (data) => {
    if (data) {
      config = { ...config, ...data };
      applyViewerTranslations();
      applyBionicClasses();
      updateReaderUIState();
      updateProgressDisplay();
      if (config.enabled && words.length > 0) {
        enableReader();
      }
    }
  });

  // Escuchar cambios reactivos en vivo (desde popup u otra pestaña)
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== 'sync') return;

    let shouldUpdateHighlight = false;
    let bionicClassesChanged = false;
    let bionicAmountChanged = false;
    let beelineChanged = false;
    let tunnelChanged = false;

    if (changes.language) {
      config.language = changes.language.newValue;
      applyViewerTranslations();
      updateReaderUIState();
      updateProgressDisplay();
    }
    if (changes.scrollMode) {
      config.scrollMode = changes.scrollMode.newValue;
    }
    if (changes.color) {
      config.color = changes.color.newValue;
      shouldUpdateHighlight = true;
    }
    if (changes.colorHighlight !== undefined) {
      config.colorHighlight = Boolean(changes.colorHighlight.newValue);
      shouldUpdateHighlight = true;
    }
    if (changes.bionicBold !== undefined || changes.bionicUpper !== undefined) {
      if (changes.bionicBold !== undefined) config.bionicBold = Boolean(changes.bionicBold.newValue);
      if (changes.bionicUpper !== undefined) config.bionicUpper = Boolean(changes.bionicUpper.newValue);
      bionicClassesChanged = true;
    }
    if (changes.bionicAmount !== undefined) {
      config.bionicAmount = parseInt(changes.bionicAmount.newValue, 10) || 1;
      bionicAmountChanged = true;
    }
    if (changes.wordCount) {
      config.wordCount = parseInt(changes.wordCount.newValue, 10) || 1;
      shouldUpdateHighlight = true;
    }
    if (changes.sensitivity) {
      config.sensitivity = parseInt(changes.sensitivity.newValue, 10) || 50;
    }

    if (changes.tunnelEnabled !== undefined || changes.tunnelSize !== undefined || changes.tunnelBlur !== undefined) {
      if (changes.tunnelEnabled !== undefined) config.tunnelEnabled = Boolean(changes.tunnelEnabled.newValue);
      if (changes.tunnelSize !== undefined) config.tunnelSize = parseInt(changes.tunnelSize.newValue, 10) || 180;
      if (changes.tunnelBlur !== undefined) config.tunnelBlur = parseInt(changes.tunnelBlur.newValue, 10) || 8;
      tunnelChanged = true;
    }

    if (changes.beelineEnabled !== undefined || changes.beelineColor1 !== undefined || changes.beelineColor2 !== undefined || changes.beelineIntensity !== undefined) {
      if (changes.beelineEnabled !== undefined) config.beelineEnabled = Boolean(changes.beelineEnabled.newValue);
      if (changes.beelineColor1 !== undefined) config.beelineColor1 = changes.beelineColor1.newValue;
      if (changes.beelineColor2 !== undefined) config.beelineColor2 = changes.beelineColor2.newValue;
      if (changes.beelineIntensity !== undefined) config.beelineIntensity = parseInt(changes.beelineIntensity.newValue, 10) || 60;
      beelineChanged = true;
    }

    if (changes.celebrateEnabled !== undefined) {
      config.celebrateEnabled = Boolean(changes.celebrateEnabled.newValue);
    }
    if (changes.celebrateStep !== undefined) {
      config.celebrateStep = parseInt(changes.celebrateStep.newValue, 10) || 25;
    }

    if (bionicClassesChanged) {
      applyBionicClasses();
    }
    if (bionicAmountChanged) {
      refreshBionicSpans();
    }
    if (beelineChanged) {
      applyBeeLine();
    }
    if (tunnelChanged) {
      updateTunnel(words[currentIndex]);
    }

    if (changes.enabled !== undefined) {
      const newEnabled = Boolean(changes.enabled.newValue);
      if (newEnabled !== config.enabled) {
        config.enabled = newEnabled;
        if (config.enabled) {
          enableReader();
        } else {
          disableReader();
        }
        updateReaderUIState();
        return;
      }
    }

    if (config.enabled && shouldUpdateHighlight && words.length > 0) {
      updateHighlight();
    }
  });
} else {
  applyBionicClasses();
}

// ========================================================
// 2. Control de eventos de Archivo y Drag & Drop
// ========================================================

btnSelectFile.addEventListener('click', () => {
  fileInput.value = '';
  fileInput.click();
});

dropZone.addEventListener('click', () => {
  fileInput.value = '';
  fileInput.click();
});

dropZone.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' || e.key === ' ') {
    e.preventDefault();
    fileInput.value = '';
    fileInput.click();
  }
});

fileInput.addEventListener('change', (e) => {
  const file = e.target.files && e.target.files[0];
  if (file) {
    handleFile(file);
  }
});

// Drag & drop robusto con contador para evitar parpadeos
let dragCounter = 0;

window.addEventListener('dragenter', (e) => {
  e.preventDefault();
  dragCounter++;
  dropZone.classList.add('dragover');
  documentWrapper.classList.add('dragover');
});

window.addEventListener('dragleave', (e) => {
  e.preventDefault();
  dragCounter--;
  if (dragCounter <= 0) {
    dragCounter = 0;
    dropZone.classList.remove('dragover');
    documentWrapper.classList.remove('dragover');
  }
});

window.addEventListener('dragover', (e) => {
  e.preventDefault();
  if (e.dataTransfer) {
    e.dataTransfer.dropEffect = 'copy';
  }
});

window.addEventListener('drop', (e) => {
  e.preventDefault();
  dragCounter = 0;
  dropZone.classList.remove('dragover');
  documentWrapper.classList.remove('dragover');

  const dt = e.dataTransfer;
  if (dt && dt.files && dt.files.length > 0) {
    handleFile(dt.files[0]);
  }
});

// ========================================================
// 3. Procesamiento de archivos (.docx y .pdf)
// ========================================================

async function handleFile(file) {
  const fileName = file.name || 'documento';
  const lowerName = fileName.toLowerCase();

  const isDocx = lowerName.endsWith('.docx');
  const isPdf = lowerName.endsWith('.pdf');

  if (!isDocx && !isPdf) {
    alert('Formato no compatible. Por favor sube un archivo con extensión .pdf o .docx.');
    return;
  }

  showLoading(`Cargando ${fileName}...`);
  docNameEl.textContent = fileName;
  docNameEl.title = fileName;

  try {
    const arrayBuffer = await file.arrayBuffer();

    if (isDocx) {
      showLoading('Extrayendo texto del documento Word (.docx)...');
      await processDocx(arrayBuffer);
    } else if (isPdf) {
      await processPdf(arrayBuffer);
    }

    // Mostrar contenedor del documento y ocultar zona de drop inicial
    dropZone.style.display = 'none';
    documentWrapper.style.display = 'block';

    // Desplazar la vista al inicio del documento
    window.scrollTo({ top: 0, behavior: 'instant' });

    // Tokenizar todas las palabras del documento
    tokenizeDocument();

    // Activar o actualizar el resalte según el estado actual
    if (config.enabled && words.length > 0) {
      enableReader();
    } else {
      updateProgressDisplay();
    }

  } catch (err) {
    console.error('[SWR Viewer] Error al procesar el archivo:', err);
    alert('Ocurrió un error al procesar el archivo: ' + (err.message || err));
  } finally {
    hideLoading();
  }
}

// Procesar Word (.docx) usando Mammoth.js
async function processDocx(arrayBuffer) {
  const mammothLib = window.mammoth || (typeof mammoth !== 'undefined' ? mammoth : null);
  if (!mammothLib) {
    throw new Error('La librería Mammoth.js no está disponible en el entorno.');
  }

  const result = await mammothLib.convertToHtml({ arrayBuffer });
  const html = result.value ? result.value.trim() : '';

  if (!html) {
    viewerContent.innerHTML = '<p class="pdf-empty-page"><em>El documento Word no contiene texto editable.</em></p>';
  } else {
    viewerContent.innerHTML = html;
  }

  if (result.messages && result.messages.length > 0) {
    console.debug('[SWR Mammoth] Mensajes de conversión:', result.messages);
  }
}

// Procesar PDF usando PDF.js
async function processPdf(arrayBuffer) {
  const loadingTask = pdfjsLib.getDocument({
    data: new Uint8Array(arrayBuffer),
    cMapUrl: undefined,
    standardFontDataUrl: undefined
  });

  const pdfDoc = await loadingTask.promise;
  const numPages = pdfDoc.numPages;

  if (numPages === 0) {
    viewerContent.innerHTML = '<p class="pdf-empty-page"><em>El documento PDF no contiene páginas.</em></p>';
    return;
  }

  let fullHtml = '';

  for (let pageNum = 1; pageNum <= numPages; pageNum++) {
    loadingText.textContent = `Extrayendo texto: Página ${pageNum} de ${numPages}...`;

    const page = await pdfDoc.getPage(pageNum);
    const textContent = await page.getTextContent();

    let pageParagraphsHtml = '';
    let currentParagraph = '';
    let lastY = null;
    let lastHeight = 12;

    for (const item of textContent.items) {
      if (typeof item.str !== 'string') continue;
      const str = item.str;

      // item.transform es [scaleX, skewY, skewX, scaleY, transX, transY]
      const currentY = (item.transform && item.transform.length >= 6) ? item.transform[5] : null;
      const currentHeight = item.height || (item.transform ? Math.abs(item.transform[3]) : 12);

      if (lastY !== null && currentY !== null) {
        const deltaY = Math.abs(currentY - lastY);

        // Si hay salto de línea vertical perceptible
        if (deltaY > 4) {
          // Si el salto supera 1.5 veces la altura de la fuente, se considera un nuevo párrafo
          const isParagraphBreak = deltaY > (Math.max(currentHeight, lastHeight) * 1.5);

          if (isParagraphBreak) {
            if (currentParagraph.trim().length > 0) {
              pageParagraphsHtml += `<p>${escapeHtml(currentParagraph.trim())}</p>`;
              currentParagraph = '';
            }
          } else {
            // Mismo párrafo, continuación en la siguiente línea física
            if (currentParagraph.length > 0 && !currentParagraph.endsWith(' ') && !currentParagraph.endsWith('-')) {
              currentParagraph += ' ';
            }
          }
        } else {
          // Misma línea horizontal: verificar si falta espacio entre ítems contiguos
          if (
            currentParagraph.length > 0 &&
            !currentParagraph.endsWith(' ') &&
            !str.startsWith(' ') &&
            !/^[.,;:!?%)\]}]/.test(str)
          ) {
            currentParagraph += ' ';
          }
        }
      }

      currentParagraph += str;
      if (currentY !== null) lastY = currentY;
      lastHeight = currentHeight;
    }

    if (currentParagraph.trim().length > 0) {
      pageParagraphsHtml += `<p>${escapeHtml(currentParagraph.trim())}</p>`;
    }

    const pageContent = pageParagraphsHtml.trim().length > 0
      ? pageParagraphsHtml
      : '<p class="pdf-empty-page"><em>(Página sin texto detectable)</em></p>';

    fullHtml += `
      <div class="pdf-page-container" data-page="${pageNum}">
        <div class="pdf-page-divider" role="separator" aria-label="Página ${pageNum} de ${numPages}">Página ${pageNum} de ${numPages}</div>
        <div class="pdf-page-body">${pageContent}</div>
      </div>
    `;
  }

  viewerContent.innerHTML = fullHtml;
}

function escapeHtml(str) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function showLoading(text) {
  loadingText.textContent = text;
  loadingOverlay.style.display = 'flex';
}

function hideLoading() {
  loadingOverlay.style.display = 'none';
}

// ========================================================
// 4. Tokenizador de palabras: Envolver en <span class="swr-word">
// ========================================================

function tokenizeDocument() {
  words = [];
  currentIndex = 0;
  lastHighlightedWords = [];
  scrollAccumulator = 0;

  // Recorrer todos los nodos de texto excluyendo separadores de página y scripts
  const walker = document.createTreeWalker(
    viewerContent,
    NodeFilter.SHOW_TEXT,
    {
      acceptNode: (node) => {
        const parent = node.parentElement;
        if (!parent) return NodeFilter.FILTER_REJECT;
        if (parent.closest('.pdf-page-divider, script, style')) {
          return NodeFilter.FILTER_REJECT;
        }
        return node.nodeValue.trim().length > 0
          ? NodeFilter.FILTER_ACCEPT
          : NodeFilter.FILTER_REJECT;
      }
    }
  );

  const textNodes = [];
  while (walker.nextNode()) {
    textNodes.push(walker.currentNode);
  }

  for (let i = 0; i < textNodes.length; i++) {
    const node = textNodes[i];
    const fragment = document.createDocumentFragment();
    const parts = node.nodeValue.split(/(\s+)/);

    for (let p = 0; p < parts.length; p++) {
      const part = parts[p];
      if (/\S/.test(part)) {
        const span = document.createElement('span');
        span.className = 'swr-word';
        span.dataset.swrIdx = String(words.length);
        span.dataset.rawWord = part;

        buildWordSpanContent(span, part, config.bionicAmount);

        words.push(span);
        fragment.appendChild(span);
      } else if (part.length > 0) {
        fragment.appendChild(document.createTextNode(part));
      }
    }

    if (node.parentNode) {
      node.parentNode.replaceChild(fragment, node);
    }
  }

  if (config.beelineEnabled) {
    applyBeeLine();
  }

  updateProgressDisplay();
}

// Estructurar el contenido de la palabra con Bionic Reading
function buildWordSpanContent(span, rawPart, amount) {
  span.textContent = '';
  const match = rawPart.match(/^([^a-zA-Z0-9áéíóúÁÉÍÓÚñÑüÜ]*)([a-zA-Z0-9áéíóúÁÉÍÓÚñÑüÜ]+)(.*)$/);
  if (match) {
    const leadingPunct = match[1];
    const wordLetters = match[2];
    const trailing = match[3];

    if (wordLetters.length > 2) {
      const pct = parseInt(amount, 10) || 1;
      const fixLen = (pct <= 1)
        ? 1
        : Math.max(1, Math.min(wordLetters.length - 1, Math.ceil(wordLetters.length * (pct / 100))));

      const lead = wordLetters.substring(0, fixLen);
      const rest = wordLetters.substring(fixLen);

      if (leadingPunct) span.appendChild(document.createTextNode(leadingPunct));
      const leadSpan = document.createElement('span');
      leadSpan.className = 'swr-lead';
      leadSpan.textContent = lead;
      span.appendChild(leadSpan);
      if (rest || trailing) span.appendChild(document.createTextNode(rest + trailing));
      return;
    }
  }
  span.textContent = rawPart;
}

// Refrescar Bionic en todas las palabras del documento
function refreshBionicSpans() {
  const amount = parseInt(config.bionicAmount, 10) || 1;
  for (let i = 0; i < words.length; i++) {
    const span = words[i];
    const raw = span.dataset.rawWord;
    if (raw) {
      buildWordSpanContent(span, raw, amount);
    }
  }
}

// Conversión Hex a RGB
function hexToRgb(hex) {
  if (!hex || typeof hex !== 'string') return { r: 37, g: 99, b: 235 };
  let c = hex.replace('#', '').trim();
  if (c.length === 3) c = c.split('').map(x => x + x).join('');
  if (c.length !== 6) return { r: 37, g: 99, b: 235 };
  return {
    r: parseInt(c.substring(0, 2), 16) || 0,
    g: parseInt(c.substring(2, 4), 16) || 0,
    b: parseInt(c.substring(4, 6), 16) || 0
  };
}

// Función BeeLine: gradiente continuo entre líneas
function applyBeeLine() {
  if (!words.length) return;

  if (!config.beelineEnabled) {
    if (beelineApplied) {
      for (let i = 0; i < words.length; i++) {
        const w = words[i];
        if (w.dataset.beelineColor) {
          delete w.dataset.beelineColor;
          if (!w.classList.contains('swr-active')) {
            w.style.color = '';
          }
        }
      }
      beelineApplied = false;
    }
    return;
  }

  const c1 = hexToRgb(config.beelineColor1 || '#2563eb');
  const c2 = hexToRgb(config.beelineColor2 || '#dc2626');
  const opacity = (parseInt(config.beelineIntensity, 10) || 60) / 100;

  let currentLineTop = null;
  let currentLine = [];
  const lines = [];

  for (let i = 0; i < words.length; i++) {
    const w = words[i];
    const top = Math.round(w.offsetTop);
    if (currentLineTop === null || Math.abs(top - currentLineTop) > 6) {
      if (currentLine.length) lines.push(currentLine);
      currentLine = [w];
      currentLineTop = top;
    } else {
      currentLine.push(w);
    }
  }
  if (currentLine.length) lines.push(currentLine);

  for (let l = 0; l < lines.length; l++) {
    const lineWords = lines[l];
    const isEven = (l % 2 === 0);
    const start = isEven ? c1 : c2;
    const end = isEven ? c2 : c1;
    const len = lineWords.length;

    for (let w = 0; w < len; w++) {
      const ratio = len > 1 ? (w / (len - 1)) : 0.5;
      const r = Math.round(start.r + (end.r - start.r) * ratio);
      const g = Math.round(start.g + (end.g - start.g) * ratio);
      const b = Math.round(start.b + (end.b - start.b) * ratio);
      const colorStr = `rgba(${r}, ${g}, ${b}, ${opacity})`;

      const span = lineWords[w];
      span.dataset.beelineColor = colorStr;
      if (!span.classList.contains('swr-active')) {
        span.style.color = colorStr;
      }
    }
  }
  beelineApplied = true;
}

// Modo Túnel: difuminar áreas arriba y abajo del foco de lectura
function updateTunnel(activeWord) {
  const topEl = document.getElementById('swr-tunnel-top');
  const bottomEl = document.getElementById('swr-tunnel-bottom');
  if (!topEl || !bottomEl) return;

  if (!config.enabled || !config.tunnelEnabled || !activeWord) {
    topEl.style.display = 'none';
    bottomEl.style.display = 'none';
    return;
  }

  topEl.style.display = 'block';
  bottomEl.style.display = 'block';

  const blurPx = Math.max(1, parseInt(config.tunnelBlur, 10) || 8);
  const filterVal = `blur(${blurPx}px)`;
  topEl.style.backdropFilter = filterVal;
  topEl.style.webkitBackdropFilter = filterVal;
  bottomEl.style.backdropFilter = filterVal;
  bottomEl.style.webkitBackdropFilter = filterVal;

  const rect = activeWord.getBoundingClientRect();
  const activeCenterY = rect.top + (rect.height / 2);
  const aperture = Math.max(60, parseInt(config.tunnelSize, 10) || 180);
  const halfAperture = aperture / 2;
  const vh = window.innerHeight || document.documentElement.clientHeight;

  const topH = Math.max(0, activeCenterY - halfAperture);
  const bottomH = Math.max(0, vh - (activeCenterY + halfAperture));

  topEl.style.height = `${Math.round(topH)}px`;
  bottomEl.style.height = `${Math.round(bottomH)}px`;
}

// Felicitaciones por porcentaje en el documento
function checkProgressMilestone() {
  if (!config.celebrateEnabled || !words.length) return;
  const progressPct = Math.floor((currentIndex / (words.length - 1 || 1)) * 100);
  const step = Math.max(5, parseInt(config.celebrateStep, 10) || 25);
  const currentMilestone = Math.floor(progressPct / step) * step;

  if (currentMilestone > 0 && currentMilestone > lastCelebratedMilestone && currentMilestone <= 100) {
    lastCelebratedMilestone = currentMilestone;
    if (progressBarEl) {
      progressBarEl.classList.add('swr-progress-glow');
      setTimeout(() => progressBarEl.classList.remove('swr-progress-glow'), 2200);
    }
    const dict = getViewerDict();
    showToast(dict.milestone(currentMilestone));
    triggerConfetti();
  }
}

// Efecto festivo de confeti
function triggerConfetti() {
  const emojis = ['🎉', '✨', '🌟', '🚀', '👏', '🎯'];
  const container = document.body;
  const vh = window.innerHeight || 600;
  const vw = window.innerWidth || 800;

  for (let i = 0; i < 18; i++) {
    const particle = document.createElement('div');
    particle.className = 'swr-confetti-particle';
    particle.textContent = emojis[Math.floor(Math.random() * emojis.length)];
    particle.style.left = `${Math.random() * (vw - 80) + 40}px`;
    particle.style.top = `${vh * 0.45 + (Math.random() * 120 - 60)}px`;
    particle.style.animationDelay = `${Math.random() * 0.35}s`;
    container.appendChild(particle);

    setTimeout(() => {
      if (particle.parentNode) {
        particle.parentNode.removeChild(particle);
      }
    }, 2200);
  }
}

// Clic directo en cualquier palabra para saltar a ella
viewerContent.addEventListener('click', (e) => {
  const target = e.target.closest('.swr-word');
  if (!target) return;

  const idx = parseInt(target.dataset.swrIdx, 10);
  if (!isNaN(idx) && idx >= 0 && idx < words.length) {
    currentIndex = idx;
    if (!config.enabled) {
      setReaderState(true);
      showToast('Modo lectura: Activado');
    } else {
      updateHighlight();
    }
  }
});

// ========================================================
// 5. Motor de lectura y resalte
// ========================================================

function enableReader() {
  window.addEventListener('wheel', handleWheel, { passive: false });
  updateHighlight();
  updateReaderUIState();
  if (config.beelineEnabled) {
    applyBeeLine();
  }
}

function disableReader() {
  window.removeEventListener('wheel', handleWheel, { passive: false });
  clearLastHighlights();
  updateReaderUIState();

  const topEl = document.getElementById('swr-tunnel-top');
  const bottomEl = document.getElementById('swr-tunnel-bottom');
  if (topEl) topEl.style.display = 'none';
  if (bottomEl) bottomEl.style.display = 'none';
}

function clearLastHighlights() {
  if (lastHighlightedWords.length > 0) {
    for (let i = 0; i < lastHighlightedWords.length; i++) {
      const w = lastHighlightedWords[i];
      if (w) {
        w.style.backgroundColor = '';
        w.style.color = w.dataset.beelineColor || '';
        w.style.outline = '';
        w.classList.remove('swr-active');
      }
    }
    lastHighlightedWords = [];
  }
}

function getContrastColor(hex) {
  if (!hex || typeof hex !== 'string' || hex[0] !== '#') return '#0f172a';
  let cleanHex = hex.replace('#', '');
  if (cleanHex.length === 3) {
    cleanHex = cleanHex.split('').map(c => c + c).join('');
  }
  if (cleanHex.length !== 6) return '#0f172a';
  const r = parseInt(cleanHex.substring(0, 2), 16) || 0;
  const g = parseInt(cleanHex.substring(2, 4), 16) || 0;
  const b = parseInt(cleanHex.substring(4, 6), 16) || 0;
  const yiq = (r * 299 + g * 587 + b * 114) / 1000;
  return yiq >= 128 ? '#0f172a' : '#ffffff';
}

function updateHighlight() {
  if (!words.length || !config.enabled) return;

  clearLastHighlights();

  const count = Math.max(1, parseInt(config.wordCount, 10) || 1);
  const textColor = getContrastColor(config.color);
  const isColorActive = config.colorHighlight !== false;

  for (let i = 0; i < count; i++) {
    const target = words[currentIndex + i];
    if (target) {
      if (isColorActive) {
        target.style.backgroundColor = config.color;
        target.style.color = textColor;
        target.style.outline = '1px solid rgba(0, 0, 0, 0.15)';
      } else {
        // Recorrido con colores apagado: borde enfocado sin color de fondo
        target.style.backgroundColor = 'transparent';
        target.style.color = target.dataset.beelineColor || '';
        target.style.outline = '2px solid ' + config.color;
      }
      target.classList.add('swr-active');
      lastHighlightedWords.push(target);
    }
  }

  // Auto-scroll suave centrado en el medio del grupo subrayado si sale del área visible
  const activeWord = words[currentIndex + Math.floor((count - 1) / 2)] || words[currentIndex];
  if (activeWord) {
    ensureWordVisible(activeWord);
    updateTunnel(activeWord);
  }

  checkProgressMilestone();
  updateProgressDisplay();
}

function ensureWordVisible(word) {
  if (!word) return;
  if (config.scrollMode === 'center') {
    word.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'nearest' });
    return;
  }
  const rect = word.getBoundingClientRect();
  const vh = window.innerHeight;
  // Margen superior respetando la barra superior sticky (~64px)
  const topLimit = 85;
  const bottomLimit = vh - 85;

  if (rect.top < topLimit || rect.bottom > bottomLimit) {
    word.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'nearest' });
  }
}

function updateProgressDisplay() {
  const dict = getViewerDict();
  if (!words.length) {
    docProgressEl.textContent = dict.zeroProgress;
    progressBarEl.style.width = '0%';
    progressBarEl.setAttribute('aria-valuenow', '0');
    return;
  }

  const current = Math.min(words.length, currentIndex + 1);
  const total = words.length;
  const pct = Math.min(100, Math.max(0, Math.round((current / total) * 100)));

  docProgressEl.textContent = dict.wordProgress(current, total, pct);
  progressBarEl.style.width = `${pct}%`;
  progressBarEl.setAttribute('aria-valuenow', String(pct));
}

// ========================================================
// 6. Rueda del ratón con acumulación de deltaY y avance fluido 1 a 1
// ========================================================

function handleWheel(e) {
  if (!config.enabled || !words.length) return;
  e.preventDefault();

  scrollAccumulator += e.deltaY;
  const threshold = Math.max(10, parseInt(config.sensitivity, 10) || 50);

  if (Math.abs(scrollAccumulator) >= threshold) {
    const steps = Math.trunc(scrollAccumulator / threshold);
    // Avanzar de una en una en ventana deslizante fluida
    const nextIndex = Math.max(0, Math.min(words.length - 1, currentIndex + steps));
    if (nextIndex !== currentIndex) {
      currentIndex = nextIndex;
      updateHighlight();
    }
    scrollAccumulator = scrollAccumulator % threshold;
  }
}

// ========================================================
// 7. Alternancia de estado (Toggle), UI y Atajos
// ========================================================

function setReaderState(enabled) {
  config.enabled = enabled;
  if (config.enabled) {
    enableReader();
  } else {
    disableReader();
  }
  updateReaderUIState();

  if (typeof chrome !== 'undefined' && chrome.storage?.sync) {
    chrome.storage.sync.set({ enabled: config.enabled });
  }
}

function toggleReader() {
  const dict = getViewerDict();
  setReaderState(!config.enabled);
  showToast(config.enabled ? dict.toastReaderOn : dict.toastReaderOff);
}

function updateReaderUIState() {
  const dict = getViewerDict();
  if (config.enabled) {
    btnToggleReader.classList.add('active');
    btnToggleReader.textContent = dict.readerOnBtn;
    btnToggleReader.setAttribute('aria-pressed', 'true');
    floatingBtn.classList.add('active');
    floatingBtn.setAttribute('aria-pressed', 'true');
  } else {
    btnToggleReader.classList.remove('active');
    btnToggleReader.textContent = dict.readerOffBtn;
    btnToggleReader.setAttribute('aria-pressed', 'false');
    floatingBtn.classList.remove('active');
    floatingBtn.setAttribute('aria-pressed', 'false');
  }
}

function showToast(message) {
  if (!toastEl) return;
  toastEl.textContent = message;
  toastEl.classList.add('show');
  if (toastTimeout) clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => {
    toastEl.classList.remove('show');
  }, 1800);
}

// Alternar recorrido con colores (Alt + C)
function toggleColorHighlight() {
  const dict = getViewerDict();
  config.colorHighlight = !config.colorHighlight;
  if (typeof chrome !== 'undefined' && chrome.storage?.sync) {
    chrome.storage.sync.set({ colorHighlight: config.colorHighlight });
  }
  showToast(config.colorHighlight ? dict.toastColorOn : dict.toastColorOff);
  if (config.enabled) {
    updateHighlight();
  }
}

// Event listeners para botones de interfaz
btnToggleReader.addEventListener('click', toggleReader);
floatingBtn.addEventListener('click', toggleReader);

// Atajos de teclado: Alt + R (Modo Lectura) y Alt + C (Recorrido con color)
window.addEventListener('keydown', (e) => {
  if (e.altKey && (e.key === 'r' || e.key === 'R' || e.code === 'KeyR')) {
    e.preventDefault();
    toggleReader();
    return;
  }
  if (e.altKey && (e.key === 'c' || e.key === 'C' || e.code === 'KeyC')) {
    e.preventDefault();
    toggleColorHighlight();
    return;
  }
});

// Escuchar scroll y resize para actualizar túnel y BeeLine
window.addEventListener('scroll', () => {
  if (config.enabled && config.tunnelEnabled && words[currentIndex]) {
    updateTunnel(words[currentIndex]);
  }
}, { passive: true });

window.addEventListener('resize', () => {
  if (config.beelineEnabled) {
    applyBeeLine();
  }
  if (config.enabled && config.tunnelEnabled && words[currentIndex]) {
    updateTunnel(words[currentIndex]);
  }
}, { passive: true });

// ========================================================
// 8. Integración con Google Docs vía URL (?docId=... o ?docUrl=...)
// ========================================================

async function checkUrlParamsForGoogleDoc() {
  const urlParams = new URLSearchParams(window.location.search);
  const docId = urlParams.get('docId');
  const title = urlParams.get('title') || 'Documento de Google Docs';

  if (docId) {
    await loadGoogleDoc(docId, title);
  }
}

async function loadGoogleDoc(docId, title) {
  showLoading(`Descargando y procesando Google Doc: "${title}"...`);
  docNameEl.textContent = title;

  try {
    const exportUrl = `https://docs.google.com/document/d/${encodeURIComponent(docId)}/export?format=docx`;
    const response = await fetch(exportUrl, { credentials: 'include' });

    if (!response.ok) {
      throw new Error(`No se pudo exportar el documento de Google (Código HTTP: ${response.status}). Asegúrate de tener permisos de lectura en la cuenta activa.`);
    }

    const arrayBuffer = await response.arrayBuffer();
    await processDocx(arrayBuffer);

    if (dropZone) dropZone.style.display = 'none';
    if (documentWrapper) documentWrapper.style.display = 'block';

    tokenizeDocument();

    // Activar modo lectura automáticamente
    setReaderState(true);
    showToast('¡Google Doc cargado correctamente!');
  } catch (err) {
    console.error('[SWR Viewer] Error al cargar Google Doc:', err);
    alert('Error al cargar el documento de Google Docs:\n' + err.message + '\n\nTip: También puedes descargarlo como .docx o .pdf desde Google Docs y soltarlo aquí.');
  } finally {
    hideLoading();
  }
}

// Comprobar parámetros de URL al iniciar
checkUrlParamsForGoogleDoc();
