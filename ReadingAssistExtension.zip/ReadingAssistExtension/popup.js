// ========================================================
// Scroll Word Reader - Popup Script
// Soporte bilingüe (ES / EN) y centrado continuo de scroll
// ========================================================

const els = {
  enabled: document.getElementById('enabled'),
  statusLabel: document.getElementById('statusLabel'),
  statusBadge: document.getElementById('statusBadge'),
  mainToggleCard: document.getElementById('mainToggleCard'),
  color: document.getElementById('color'),
  colorVal: document.getElementById('colorVal'),
  colorHighlight: document.getElementById('colorHighlight'),
  scrollModeNatural: document.getElementById('scrollModeNatural'),
  scrollModeCenter: document.getElementById('scrollModeCenter'),
  langBtnEs: document.getElementById('langBtnEs'),
  langBtnEn: document.getElementById('langBtnEn'),
  bionicBold: document.getElementById('bionicBold'),
  bionicUpper: document.getElementById('bionicUpper'),
  bionicAmount: document.getElementById('bionicAmount'),
  bionicAmountVal: document.getElementById('bionicAmountVal'),
  wordCount: document.getElementById('wordCount'),
  wordCountVal: document.getElementById('wordCountVal'),
  wordCountUnit: document.getElementById('wordCountUnit'),
  sensitivity: document.getElementById('sensitivity'),
  sensVal: document.getElementById('sensVal'),
  tunnelEnabled: document.getElementById('tunnelEnabled'),
  tunnelSettings: document.getElementById('tunnelSettings'),
  tunnelSize: document.getElementById('tunnelSize'),
  tunnelSizeVal: document.getElementById('tunnelSizeVal'),
  tunnelBlur: document.getElementById('tunnelBlur'),
  tunnelBlurVal: document.getElementById('tunnelBlurVal'),
  beelineEnabled: document.getElementById('beelineEnabled'),
  beelineSettings: document.getElementById('beelineSettings'),
  beelineColor1: document.getElementById('beelineColor1'),
  beelineColor2: document.getElementById('beelineColor2'),
  beelineIntensity: document.getElementById('beelineIntensity'),
  beelineIntensityVal: document.getElementById('beelineIntensityVal'),
  celebrateEnabled: document.getElementById('celebrateEnabled'),
  celebrateSettings: document.getElementById('celebrateSettings'),
  celebrateStep: document.getElementById('celebrateStep'),
  openViewer: document.getElementById('openViewer'),
  openLandingBtn: document.getElementById('openLandingBtn'),
  presetButtons: Array.from(document.querySelectorAll('.color-preset-btn'))
};

const I18N = {
  es: {
    appTitle: 'Scroll Word Reader',
    appSub: 'Lectura asistida interactiva',
    langLabel: 'Idioma / Language',
    readingMode: 'Modo Lectura',
    active: 'Activado',
    inactive: 'Desactivado',
    highlightColor: 'Color de subrayado',
    wordsPerStep: 'Palabras subrayadas a la vez',
    wordSingular: 'palabra',
    wordPlural: 'palabras',
    wheelSensitivity: 'Sensibilidad de rueda',
    scrollModeLabel: 'Desplazamiento del texto',
    scrollModeNatural: 'Margen natural',
    scrollModeCenter: 'Siempre en el medio',
    colorTrail: 'Recorrido con colores',
    colorTrailSub: 'Pintar fondo al avanzar (Alt+C)',
    bionicTitle: 'Énfasis de 1ª letra (> 2 letras)',
    bionicBadge: 'Lectura rápida',
    bionicBoldLabel: 'Primera letra en <strong>Negrita</strong>',
    bionicUpperLabel: 'Primera letra en <strong>MAYÚSCULA</strong>',
    bionicAmountLabel: 'Parte de palabra remarcada',
    firstLetterOnly: '1ª letra',
    percentOfWord: '% palabra',
    tunnelTitle: 'Modo Túnel (Focus Blur)',
    tunnelSub: 'Difuminar arriba y abajo de la lectura',
    tunnelSizeLabel: 'Apertura de lectura',
    tunnelBlurLabel: 'Intensidad de desenfoque',
    beelineTitle: 'Función BeeLine Reader',
    beelineSub: 'Gradiente cromático entre líneas',
    beelineColorsLabel: 'Colores de transición',
    beelineStart: 'Inicio:',
    beelineEnd: 'Fin:',
    beelineIntensityLabel: 'Intensidad',
    celebrateTitle: 'Felicitaciones de Progreso',
    celebrateSub: 'Mensajes y animación al alcanzar hitos',
    celebrateEvery: 'Frecuencia del hito',
    step10: 'Cada 10% del documento',
    step20: 'Cada 20% del documento',
    step25: 'Cada 25% (un cuarto del texto)',
    step50: 'Cada 50% (mitad y final)',
    gdocsDetected: '📄 Google Doc detectado',
    openGDocsBtn: 'Leer Google Doc en Visor',
    openViewerBtn: 'Abrir Visor PDF / Word',
    openLandingBtn: 'Guía de Atajos y Funciones',
    shortcutMode: 'Modo lectura:',
    shortcutColor: 'Recorrido con color:',
    footerHint: 'Haz clic en cualquier palabra para situar el foco'
  },
  en: {
    appTitle: 'Scroll Word Reader',
    appSub: 'Interactive assisted reading',
    langLabel: 'Language / Idioma',
    readingMode: 'Reading Mode',
    active: 'Enabled',
    inactive: 'Disabled',
    highlightColor: 'Highlight color',
    wordsPerStep: 'Words highlighted at once',
    wordSingular: 'word',
    wordPlural: 'words',
    wheelSensitivity: 'Wheel sensitivity',
    scrollModeLabel: 'Text Scrolling Behavior',
    scrollModeNatural: 'Natural margins',
    scrollModeCenter: 'Always centered',
    colorTrail: 'Color trail',
    colorTrailSub: 'Paint background on scroll (Alt+C)',
    bionicTitle: '1st letter emphasis (> 2 letters)',
    bionicBadge: 'Speed reading',
    bionicBoldLabel: 'First letter in <strong>Bold</strong>',
    bionicUpperLabel: 'First letter in <strong>UPPERCASE</strong>',
    bionicAmountLabel: 'Highlighted word portion',
    firstLetterOnly: '1st letter',
    percentOfWord: '% of word',
    tunnelTitle: 'Tunnel Mode (Focus Blur)',
    tunnelSub: 'Blur above & below reading area',
    tunnelSizeLabel: 'Reading aperture',
    tunnelBlurLabel: 'Blur intensity',
    beelineTitle: 'BeeLine Reader Feature',
    beelineSub: 'Color gradient between text lines',
    beelineColorsLabel: 'Transition colors',
    beelineStart: 'Start:',
    beelineEnd: 'End:',
    beelineIntensityLabel: 'Intensity',
    celebrateTitle: 'Progress Celebration',
    celebrateSub: 'Alerts & animations on milestones',
    celebrateEvery: 'Milestone frequency',
    step10: 'Every 10% of document',
    step20: 'Every 20% of document',
    step25: 'Every 25% (one quarter)',
    step50: 'Every 50% (half and end)',
    gdocsDetected: '📄 Google Doc detected',
    openGDocsBtn: 'Read Google Doc in Viewer',
    openViewerBtn: 'Open PDF / Word Viewer',
    openLandingBtn: 'Shortcuts & Features Guide',
    shortcutMode: 'Reading mode:',
    shortcutColor: 'Color trail:',
    footerHint: 'Click on any word to shift focus'
  }
};

const DEFAULTS = {
  language: 'es',
  scrollMode: 'natural',
  enabled: false,
  colorHighlight: true,
  bionicBold: false,
  bionicUpper: false,
  bionicAmount: 1,
  color: '#ffeb3b',
  wordCount: 1,
  sensitivity: 50,
  tunnelEnabled: false,
  tunnelSize: 180,
  tunnelBlur: 8,
  beelineEnabled: false,
  beelineColor1: '#2563eb',
  beelineColor2: '#dc2626',
  beelineIntensity: 60,
  celebrateEnabled: true,
  celebrateStep: 25
};

let currentLang = 'es';
let currentScrollMode = 'natural';
let debounceTimer = null;

// 1. Cargar valores iniciales desde chrome.storage.sync
function init() {
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync) {
    chrome.storage.sync.get(DEFAULTS, (data) => {
      if (chrome.runtime.lastError) {
        console.warn('Error leyendo de chrome.storage.sync:', chrome.runtime.lastError);
        applyValuesToUI(DEFAULTS);
        return;
      }
      applyValuesToUI(data || DEFAULTS);
    });
  } else {
    // Modo fallback sin extensión
    applyValuesToUI(DEFAULTS);
  }
}

// 2. Aplicar traducciones según idioma
function setLanguage(lang) {
  currentLang = (lang === 'en') ? 'en' : 'es';
  const dict = I18N[currentLang] || I18N.es;

  // Actualizar botones de idioma
  if (els.langBtnEs) els.langBtnEs.classList.toggle('active', currentLang === 'es');
  if (els.langBtnEn) els.langBtnEn.classList.toggle('active', currentLang === 'en');

  // Traducir todos los elementos con data-i18n
  document.querySelectorAll('[data-i18n]').forEach((el) => {
    const key = el.getAttribute('data-i18n');
    if (dict[key]) {
      // Si contiene etiquetas HTML (como <strong>), usar innerHTML
      if (dict[key].includes('<')) {
        el.innerHTML = dict[key];
      } else {
        el.textContent = dict[key];
      }
    }
  });

  // Actualizar unidades dinámicas
  updateDynamicUnits();
}

function updateDynamicUnits() {
  const dict = I18N[currentLang] || I18N.es;
  const wc = parseInt(els.wordCount?.value, 10) || 1;
  if (els.wordCountUnit) {
    els.wordCountUnit.textContent = wc === 1 ? dict.wordSingular : dict.wordPlural;
  }

  const amt = parseInt(els.bionicAmount?.value, 10) || 1;
  if (els.bionicAmountVal) {
    els.bionicAmountVal.textContent = amt <= 1 ? dict.firstLetterOnly : `${amt}${dict.percentOfWord}`;
  }

  if (els.statusLabel) {
    els.statusLabel.textContent = els.enabled?.checked ? dict.active : dict.inactive;
  }
}

// 3. Aplicar modo de desplazamiento
function setScrollMode(mode) {
  currentScrollMode = (mode === 'center') ? 'center' : 'natural';
  if (els.scrollModeNatural) {
    els.scrollModeNatural.classList.toggle('active', currentScrollMode === 'natural');
  }
  if (els.scrollModeCenter) {
    els.scrollModeCenter.classList.toggle('active', currentScrollMode === 'center');
  }
}

// 4. Aplicar y reflejar valores en los elementos de la interfaz de usuario
function applyValuesToUI(data) {
  if (!data) return;

  // Idioma
  if (data.language) {
    setLanguage(data.language);
  } else {
    setLanguage('es');
  }

  // Modo de desplazamiento
  if (data.scrollMode) {
    setScrollMode(data.scrollMode);
  } else {
    setScrollMode('natural');
  }

  // Toggle Modo Lectura
  if (data.enabled !== undefined && els.enabled) {
    els.enabled.checked = Boolean(data.enabled);
    updateToggleState(Boolean(data.enabled));
  }

  // Color de subrayado
  if (data.color && els.color) {
    const formattedColor = data.color.toLowerCase();
    els.color.value = formattedColor;
    if (els.colorVal) {
      els.colorVal.textContent = formattedColor;
    }
    updatePresetHighlight(formattedColor);
  }

  // Cantidad de palabras
  if (data.wordCount !== undefined && els.wordCount) {
    const wc = parseInt(data.wordCount, 10) || 1;
    els.wordCount.value = wc;
    if (els.wordCountVal) {
      els.wordCountVal.textContent = wc;
    }
  }

  // Sensibilidad de la rueda
  if (data.sensitivity !== undefined && els.sensitivity) {
    const sens = parseInt(data.sensitivity, 10) || 50;
    els.sensitivity.value = sens;
    if (els.sensVal) {
      els.sensVal.textContent = sens;
    }
  }

  // Recorrido con colores
  if (data.colorHighlight !== undefined && els.colorHighlight) {
    els.colorHighlight.checked = Boolean(data.colorHighlight);
  }

  // Énfasis Bionic
  if (data.bionicBold !== undefined && els.bionicBold) {
    els.bionicBold.checked = Boolean(data.bionicBold);
  }
  if (data.bionicUpper !== undefined && els.bionicUpper) {
    els.bionicUpper.checked = Boolean(data.bionicUpper);
  }
  if (data.bionicAmount !== undefined && els.bionicAmount) {
    const amt = parseInt(data.bionicAmount, 10) || 1;
    els.bionicAmount.value = amt;
  }

  // Modo Túnel (Focus Blur)
  if (data.tunnelEnabled !== undefined && els.tunnelEnabled) {
    const tEnabled = Boolean(data.tunnelEnabled);
    els.tunnelEnabled.checked = tEnabled;
    if (els.tunnelSettings) {
      els.tunnelSettings.style.display = tEnabled ? 'block' : 'none';
    }
  }
  if (data.tunnelSize !== undefined && els.tunnelSize) {
    const tSize = parseInt(data.tunnelSize, 10) || 180;
    els.tunnelSize.value = tSize;
    if (els.tunnelSizeVal) els.tunnelSizeVal.textContent = tSize;
  }
  if (data.tunnelBlur !== undefined && els.tunnelBlur) {
    const tBlur = parseInt(data.tunnelBlur, 10) || 8;
    els.tunnelBlur.value = tBlur;
    if (els.tunnelBlurVal) els.tunnelBlurVal.textContent = tBlur;
  }

  // Función BeeLine
  if (data.beelineEnabled !== undefined && els.beelineEnabled) {
    const bEnabled = Boolean(data.beelineEnabled);
    els.beelineEnabled.checked = bEnabled;
    if (els.beelineSettings) {
      els.beelineSettings.style.display = bEnabled ? 'block' : 'none';
    }
  }
  if (data.beelineColor1 && els.beelineColor1) {
    els.beelineColor1.value = data.beelineColor1;
  }
  if (data.beelineColor2 && els.beelineColor2) {
    els.beelineColor2.value = data.beelineColor2;
  }
  if (data.beelineIntensity !== undefined && els.beelineIntensity) {
    const bInt = parseInt(data.beelineIntensity, 10) || 60;
    els.beelineIntensity.value = bInt;
    if (els.beelineIntensityVal) els.beelineIntensityVal.textContent = bInt;
  }

  // Felicitaciones por Progreso
  if (data.celebrateEnabled !== undefined && els.celebrateEnabled) {
    const cEnabled = Boolean(data.celebrateEnabled);
    els.celebrateEnabled.checked = cEnabled;
    if (els.celebrateSettings) {
      els.celebrateSettings.style.display = cEnabled ? 'block' : 'none';
    }
  }
  if (data.celebrateStep !== undefined && els.celebrateStep) {
    els.celebrateStep.value = String(data.celebrateStep);
  }

  updateDynamicUnits();
}

// Actualizar aspecto visual del switch y estado
function updateToggleState(isActive) {
  const dict = I18N[currentLang] || I18N.es;
  if (els.statusLabel) {
    els.statusLabel.textContent = isActive ? dict.active : dict.inactive;
  }
  if (els.statusBadge) {
    els.statusBadge.classList.toggle('active', isActive);
  }
  if (els.mainToggleCard) {
    els.mainToggleCard.classList.toggle('active-state', isActive);
  }
}

// Resaltar preset de color activo
function updatePresetHighlight(selectedColor) {
  els.presetButtons.forEach((btn) => {
    const presetColor = (btn.getAttribute('data-color') || '').toLowerCase();
    btn.classList.toggle('active', presetColor === selectedColor);
  });
}

// Obtener objeto de configuración actual
function getCurrentConfig() {
  const isEnabled = els.enabled ? Boolean(els.enabled.checked) : false;
  const colorVal = els.color ? els.color.value : '#ffeb3b';
  const colorHighlight = els.colorHighlight ? Boolean(els.colorHighlight.checked) : true;
  const bionicBold = els.bionicBold ? Boolean(els.bionicBold.checked) : false;
  const bionicUpper = els.bionicUpper ? Boolean(els.bionicUpper.checked) : false;
  const bionicAmount = els.bionicAmount ? Math.max(1, Math.min(70, parseInt(els.bionicAmount.value, 10) || 1)) : 1;
  const wordCount = els.wordCount ? Math.max(1, Math.min(10, parseInt(els.wordCount.value, 10) || 1)) : 1;
  const sensitivity = els.sensitivity ? Math.max(10, Math.min(200, parseInt(els.sensitivity.value, 10) || 50)) : 50;

  const tunnelEnabled = els.tunnelEnabled ? Boolean(els.tunnelEnabled.checked) : false;
  const tunnelSize = els.tunnelSize ? Math.max(80, Math.min(360, parseInt(els.tunnelSize.value, 10) || 180)) : 180;
  const tunnelBlur = els.tunnelBlur ? Math.max(2, Math.min(25, parseInt(els.tunnelBlur.value, 10) || 8)) : 8;

  const beelineEnabled = els.beelineEnabled ? Boolean(els.beelineEnabled.checked) : false;
  const beelineColor1 = els.beelineColor1 ? els.beelineColor1.value : '#2563eb';
  const beelineColor2 = els.beelineColor2 ? els.beelineColor2.value : '#dc2626';
  const beelineIntensity = els.beelineIntensity ? Math.max(20, Math.min(100, parseInt(els.beelineIntensity.value, 10) || 60)) : 60;

  const celebrateEnabled = els.celebrateEnabled ? Boolean(els.celebrateEnabled.checked) : true;
  const celebrateStep = els.celebrateStep ? parseInt(els.celebrateStep.value, 10) || 25 : 25;

  return {
    language: currentLang,
    scrollMode: currentScrollMode,
    enabled: isEnabled,
    color: colorVal,
    colorHighlight: colorHighlight,
    bionicBold: bionicBold,
    bionicUpper: bionicUpper,
    bionicAmount: bionicAmount,
    wordCount: wordCount,
    sensitivity: sensitivity,
    tunnelEnabled: tunnelEnabled,
    tunnelSize: tunnelSize,
    tunnelBlur: tunnelBlur,
    beelineEnabled: beelineEnabled,
    beelineColor1: beelineColor1,
    beelineColor2: beelineColor2,
    beelineIntensity: beelineIntensity,
    celebrateEnabled: celebrateEnabled,
    celebrateStep: celebrateStep
  };
}

// Reflejar cambios numéricos y de texto inmediatamente en el DOM
function updateUIFromInputs() {
  const config = getCurrentConfig();
  updateToggleState(config.enabled);

  if (els.colorVal) {
    els.colorVal.textContent = config.color;
  }
  updatePresetHighlight(config.color);

  if (els.wordCountVal) {
    els.wordCountVal.textContent = config.wordCount;
  }
  if (els.sensVal) {
    els.sensVal.textContent = config.sensitivity;
  }

  if (els.tunnelSettings && els.tunnelEnabled) {
    els.tunnelSettings.style.display = config.tunnelEnabled ? 'block' : 'none';
  }
  if (els.tunnelSizeVal) {
    els.tunnelSizeVal.textContent = config.tunnelSize;
  }
  if (els.tunnelBlurVal) {
    els.tunnelBlurVal.textContent = config.tunnelBlur;
  }

  if (els.beelineSettings && els.beelineEnabled) {
    els.beelineSettings.style.display = config.beelineEnabled ? 'block' : 'none';
  }
  if (els.beelineIntensityVal) {
    els.beelineIntensityVal.textContent = config.beelineIntensity;
  }

  if (els.celebrateSettings && els.celebrateEnabled) {
    els.celebrateSettings.style.display = config.celebrateEnabled ? 'block' : 'none';
  }

  updateDynamicUnits();
  return config;
}

// Guardar en chrome.storage.sync
function persistSettings(config) {
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync) {
    chrome.storage.sync.set(config, () => {
      if (chrome.runtime.lastError) {
        console.warn('Error guardando en chrome.storage.sync:', chrome.runtime.lastError);
      }
    });
  }
}

// Guardado inmediato
function saveImmediately() {
  if (debounceTimer) {
    clearTimeout(debounceTimer);
    debounceTimer = null;
  }
  const config = updateUIFromInputs();
  persistSettings(config);
}

// Guardado con debounce para sliders
function saveDebounced() {
  const config = updateUIFromInputs();
  if (debounceTimer) {
    clearTimeout(debounceTimer);
  }
  debounceTimer = setTimeout(() => {
    persistSettings(config);
    debounceTimer = null;
  }, 100);
}

// 5. Registrar eventos de escucha para inputs interactivos
if (els.langBtnEs) {
  els.langBtnEs.addEventListener('click', () => {
    setLanguage('es');
    saveImmediately();
  });
}

if (els.langBtnEn) {
  els.langBtnEn.addEventListener('click', () => {
    setLanguage('en');
    saveImmediately();
  });
}

if (els.scrollModeNatural) {
  els.scrollModeNatural.addEventListener('click', () => {
    setScrollMode('natural');
    saveImmediately();
  });
}

if (els.scrollModeCenter) {
  els.scrollModeCenter.addEventListener('click', () => {
    setScrollMode('center');
    saveImmediately();
  });
}

if (els.enabled) {
  els.enabled.addEventListener('change', saveImmediately);
}

if (els.color) {
  els.color.addEventListener('input', () => {
    updateUIFromInputs();
    saveDebounced();
  });
  els.color.addEventListener('change', saveImmediately);
}

if (els.wordCount) {
  els.wordCount.addEventListener('input', saveDebounced);
  els.wordCount.addEventListener('change', saveImmediately);
}

if (els.sensitivity) {
  els.sensitivity.addEventListener('input', saveDebounced);
  els.sensitivity.addEventListener('change', saveImmediately);
}

if (els.colorHighlight) {
  els.colorHighlight.addEventListener('change', saveImmediately);
}

if (els.bionicBold) {
  els.bionicBold.addEventListener('change', saveImmediately);
}

if (els.bionicUpper) {
  els.bionicUpper.addEventListener('change', saveImmediately);
}

if (els.bionicAmount) {
  els.bionicAmount.addEventListener('input', saveDebounced);
  els.bionicAmount.addEventListener('change', saveImmediately);
}

if (els.tunnelEnabled) {
  els.tunnelEnabled.addEventListener('change', () => {
    if (els.tunnelSettings) {
      els.tunnelSettings.style.display = els.tunnelEnabled.checked ? 'block' : 'none';
    }
    saveImmediately();
  });
}

if (els.tunnelSize) {
  els.tunnelSize.addEventListener('input', saveDebounced);
  els.tunnelSize.addEventListener('change', saveImmediately);
}

if (els.tunnelBlur) {
  els.tunnelBlur.addEventListener('input', saveDebounced);
  els.tunnelBlur.addEventListener('change', saveImmediately);
}

if (els.beelineEnabled) {
  els.beelineEnabled.addEventListener('change', () => {
    if (els.beelineSettings) {
      els.beelineSettings.style.display = els.beelineEnabled.checked ? 'block' : 'none';
    }
    saveImmediately();
  });
}

if (els.beelineColor1) {
  els.beelineColor1.addEventListener('input', saveDebounced);
  els.beelineColor1.addEventListener('change', saveImmediately);
}

if (els.beelineColor2) {
  els.beelineColor2.addEventListener('input', saveDebounced);
  els.beelineColor2.addEventListener('change', saveImmediately);
}

if (els.beelineIntensity) {
  els.beelineIntensity.addEventListener('input', saveDebounced);
  els.beelineIntensity.addEventListener('change', saveImmediately);
}

if (els.celebrateEnabled) {
  els.celebrateEnabled.addEventListener('change', () => {
    if (els.celebrateSettings) {
      els.celebrateSettings.style.display = els.celebrateEnabled.checked ? 'block' : 'none';
    }
    saveImmediately();
  });
}

if (els.celebrateStep) {
  els.celebrateStep.addEventListener('change', saveImmediately);
}

// Presets de color
els.presetButtons.forEach((btn) => {
  btn.addEventListener('click', () => {
    const chosenColor = btn.getAttribute('data-color');
    if (chosenColor && els.color) {
      els.color.value = chosenColor;
      updateUIFromInputs();
      saveImmediately();
    }
  });
});

// Botón para abrir el Visor de Documentos
if (els.openViewer) {
  els.openViewer.addEventListener('click', () => {
    if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.create) {
      chrome.tabs.create({ url: chrome.runtime.getURL('viewer.html') });
    } else {
      window.open('viewer.html', '_blank');
    }
  });
}

// Botón para abrir la Guía Landing
if (els.openLandingBtn) {
  els.openLandingBtn.addEventListener('click', () => {
    if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.create) {
      chrome.tabs.create({ url: chrome.runtime.getURL('landing.html') });
    } else {
      window.open('landing.html', '_blank');
    }
  });
}

// 6. Escuchar chrome.storage.onChanged en tiempo real
if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== 'sync') return;

    const updated = {};
    for (const key in changes) {
      if (Object.prototype.hasOwnProperty.call(changes, key)) {
        updated[key] = changes[key].newValue;
      }
    }
    applyValuesToUI(updated);
  });
}

// 7. Detección reactiva de Google Docs en la pestaña activa
if (typeof chrome !== 'undefined' && chrome.tabs?.query) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const activeTab = tabs && tabs[0];
    if (activeTab && activeTab.url && activeTab.url.includes('docs.google.com/document/d/')) {
      const match = activeTab.url.match(/\/document\/d\/([a-zA-Z0-9-_]+)/);
      if (match) {
        const docId = match[1];
        const gdocsCard = document.getElementById('gdocsCard');
        const openGDocsBtn = document.getElementById('openGDocsBtn');
        if (gdocsCard && openGDocsBtn) {
          gdocsCard.style.display = 'block';
          openGDocsBtn.addEventListener('click', () => {
            const cleanTitle = (activeTab.title || 'Google Doc').replace(/ - Google Docs$/, '');
            const targetUrl = chrome.runtime.getURL(`viewer.html?docId=${docId}&title=${encodeURIComponent(cleanTitle)}`);
            chrome.tabs.create({ url: targetUrl });
          });
        }
      }
    }
  });
}

// Inicializar al cargar el documento
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
