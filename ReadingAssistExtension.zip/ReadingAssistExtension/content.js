// ========================================================
// Scroll Word Reader - Content Script
// High-performance word reader with wheel navigation
// Bilingual support (ES / EN) and Centered Scroll Mode
// ========================================================

(() => {
  // Configuración por defecto
  const DEFAULTS = {
    language: 'es',
    scrollMode: 'natural',
    color: '#ffeb3b',
    wordCount: 1,
    sensitivity: 50,
    enabled: false,
    colorHighlight: true,
    bionicBold: false,
    bionicUpper: false,
    bionicAmount: 1,
    tunnelEnabled: false,
    tunnelSize: 180,
    tunnelBlur: 8,
    beelineEnabled: false,
    beelineColor1: '#2563eb',
    beelineColor2: '#dc2626',
    beelineIntensity: 60,
    celebrateEnabled: true,
    celebrateStep: 25
  };

  let config = { ...DEFAULTS };
  let words = [];
  let currentIndex = 0;
  let scrollAccumulator = 0;
  let isInitialized = false;
  let lastHighlightedWords = [];
  let floatingBtn = null;
  let toastEl = null;
  let toastTimer = null;
  let lastCelebratedMilestone = 0;
  let beelineApplied = false;

  // Selector para omitir etiquetas no deseadas y elementos internos de la extensión
  const IGNORED_SELECTOR = [
    'script', 'style', 'noscript', 'textarea', 'input', 'select',
    'button', 'svg', 'canvas', 'audio', 'video', 'iframe',
    'object', 'code', 'pre', '#swr-ui-root', '.swr-ui', '[data-swr-ui]',
    '.swr-tunnel-overlay'
  ].join(', ');

  // Traducciones en tiempo de ejecución para toasts y tooltips
  function t(key, params = {}) {
    const isEn = config.language === 'en';
    const dict = {
      readerOn: isEn ? 'Reading mode: Enabled' : 'Modo lectura: Activado',
      readerOff: isEn ? 'Reading mode: Disabled' : 'Modo lectura: Desactivado',
      colorOn: isEn ? 'Color trail: Enabled' : 'Recorrido con color: Activado',
      colorOff: isEn ? 'Color trail: Disabled' : 'Recorrido con color: Desactivado',
      openGDocs: isEn ? 'Opening Google Doc in Scroll Word Reader...' : 'Abriendo Google Doc en Scroll Word Reader...',
      milestone: isEn ? `🎉 Congratulations! You completed ${params.step}% of the text` : `🎉 ¡Felicitaciones! Has completado el ${params.step}% del texto`,
      floatingBtnTitle: isEn ? 'Scroll Word Reader (Alt+R)' : 'Scroll Word Reader (Alt+R)',
      gdocsBtnTitle: isEn ? 'Open and read this Google Doc in Scroll Word Reader' : 'Abrir y leer este Google Doc en Scroll Word Reader'
    };
    return dict[key] || '';
  }

  // Aplicar clases dinámicas para Bionic Reading
  function applyBionicClasses() {
    if (document.body) {
      document.body.classList.toggle('swr-bionic-bold', Boolean(config.bionicBold));
      document.body.classList.toggle('swr-bionic-upper', Boolean(config.bionicUpper));
    }
  }

  // 1. Inicialización y carga de configuración
  function init() {
    if (typeof chrome !== 'undefined' && chrome.storage?.sync) {
      chrome.storage.sync.get(DEFAULTS, (data) => {
        if (data) {
          config = { ...config, ...data };
        }
        createFloatingUI();
        applyBionicClasses();
        if (config.enabled) {
          enableReader();
        }
      });

      // Sincronización en tiempo real con cambios en el popup o atajos
      chrome.storage.onChanged.addListener((changes, areaName) => {
        if (areaName !== 'sync') return;

        let enabledChanged = false;
        let bionicClassesChanged = false;
        let bionicAmountChanged = false;
        let beelineChanged = false;
        let tunnelChanged = false;
        let highlightChanged = false;
        let languageChanged = false;

        for (const key in changes) {
          if (key === 'enabled' && config.enabled !== changes[key].newValue) {
            enabledChanged = true;
          }
          if (key === 'language') {
            languageChanged = true;
          }
          if (key === 'bionicBold' || key === 'bionicUpper') {
            bionicClassesChanged = true;
          }
          if (key === 'bionicAmount') {
            bionicAmountChanged = true;
          }
          if (key.startsWith('beeline')) {
            beelineChanged = true;
          }
          if (key.startsWith('tunnel')) {
            tunnelChanged = true;
          }
          if (key === 'colorHighlight' || key === 'color' || key === 'wordCount' || key === 'scrollMode') {
            highlightChanged = true;
          }
          config[key] = changes[key].newValue;
        }

        if (bionicClassesChanged) {
          applyBionicClasses();
        }
        if (bionicAmountChanged) {
          refreshBionicSpans();
        }
        if (beelineChanged) {
          applyBeeLine();
        }
        if (tunnelChanged) {
          updateTunnel(words[currentIndex]);
        }
        if (languageChanged) {
          updateUITitles();
        }

        if (enabledChanged) {
          if (config.enabled) {
            enableReader();
          } else {
            disableReader();
          }
          showToast(config.enabled ? t('readerOn') : t('readerOff'));
        } else if (config.enabled && highlightChanged) {
          updateHighlight();
        }

        updateFloatingBtnStyle();
      });
    } else {
      createFloatingUI();
      applyBionicClasses();
    }

    // Atajo de teclado: Alt + R y Alt + C
    window.addEventListener('keydown', handleKeydown, true);
  }

  function updateUITitles() {
    if (floatingBtn) {
      floatingBtn.title = t('floatingBtnTitle');
    }
    const gdocsBtn = document.getElementById('swr-gdocs-btn');
    if (gdocsBtn) {
      gdocsBtn.title = t('gdocsBtnTitle');
    }
  }

  // Atajo de teclado Alt + R (Modo lectura) y Alt + C (Recorrido con colores)
  function handleKeydown(e) {
    const activeEl = document.activeElement;
    if (activeEl && (
      activeEl.tagName === 'INPUT' ||
      activeEl.tagName === 'TEXTAREA' ||
      activeEl.isContentEditable
    )) {
      return;
    }

    if (e.altKey && (e.key === 'r' || e.key === 'R' || e.code === 'KeyR')) {
      e.preventDefault();
      e.stopPropagation();
      toggleReader();
      return;
    }

    if (e.altKey && (e.key === 'c' || e.key === 'C' || e.code === 'KeyC')) {
      e.preventDefault();
      e.stopPropagation();
      toggleColorHighlight();
      return;
    }
  }

  // Alternar recorrido con color (Alt + C)
  function toggleColorHighlight() {
    config.colorHighlight = !config.colorHighlight;
    if (typeof chrome !== 'undefined' && chrome.storage?.sync) {
      chrome.storage.sync.set({ colorHighlight: config.colorHighlight });
    }
    showToast(config.colorHighlight ? t('colorOn') : t('colorOff'));
    if (config.enabled) {
      updateHighlight();
    }
  }

  // Detección e integración con Google Docs
  function isGoogleDocs() {
    return window.location.hostname === 'docs.google.com' && window.location.pathname.includes('/document/d/');
  }

  function getGoogleDocId() {
    const match = window.location.pathname.match(/\/document\/d\/([a-zA-Z0-9-_]+)/);
    return match ? match[1] : null;
  }

  function openGoogleDocInViewer() {
    const docId = getGoogleDocId();
    if (!docId) {
      showToast('No se pudo detectar el ID del Google Doc');
      return;
    }

    const cleanTitle = (document.title || 'Google Doc').replace(/ - Google Docs$/, '');
    const viewerUrl = chrome.runtime.getURL(`viewer.html?docId=${docId}&title=${encodeURIComponent(cleanTitle)}`);
    window.open(viewerUrl, '_blank');
  }

  // Alternar estado del lector
  function toggleReader() {
    // Si estamos en Google Docs y está en modo Canvas (sin texto tradicional en el DOM)
    if (isGoogleDocs()) {
      const hasCanvas = document.querySelector('canvas.kix-canvas-tile-content') || document.querySelector('.kix-canvas-tile-content');
      if (hasCanvas && words.length < 10) {
        showToast(t('openGDocs'));
        openGoogleDocInViewer();
        return;
      }
    }

    const nextState = !config.enabled;
    config.enabled = nextState;

    if (typeof chrome !== 'undefined' && chrome.storage?.sync) {
      chrome.storage.sync.set({ enabled: nextState });
    }

    showToast(nextState ? t('readerOn') : t('readerOff'));

    if (nextState) {
      enableReader();
    } else {
      disableReader();
    }

    updateFloatingBtnStyle();
  }

  // 2. Interfaz flotante (Botón SVG, Túnel y Toast)
  function createFloatingUI() {
    if (document.getElementById('swr-ui-root')) return;
    if (!document.body) {
      window.addEventListener('DOMContentLoaded', createFloatingUI, { once: true });
      return;
    }

    // Inyectar estilos CSS optimizados
    const style = document.createElement('style');
    style.id = 'swr-styles';
    style.textContent = `
      .swr-word {
        cursor: pointer;
        border-radius: 3px;
        transition: background-color 0.1s ease, color 0.1s ease, outline 0.1s ease;
        box-decoration-break: clone;
        -webkit-box-decoration-break: clone;
      }
      .swr-word:hover {
        outline: 2px dashed #3b82f6 !important;
        outline-offset: 1px;
      }
      .swr-word.swr-active {
        outline: 1px solid rgba(0, 0, 0, 0.15);
      }
      body.swr-bionic-bold .swr-lead {
        font-weight: 700 !important;
      }
      body.swr-bionic-upper .swr-lead {
        text-transform: uppercase !important;
      }
      #swr-ui-root {
        all: initial;
        position: fixed;
        z-index: 2147483647;
      }
      #swr-floating-btn {
        position: fixed;
        bottom: 24px;
        right: 24px;
        width: 48px;
        height: 48px;
        border-radius: 50%;
        background: #0f172a;
        border: 2px solid #334155;
        color: #f8fafc;
        box-shadow: 0 4px 14px rgba(0, 0, 0, 0.35);
        cursor: pointer;
        z-index: 2147483647;
        display: flex;
        align-items: center;
        justify-content: center;
        box-sizing: border-box;
        margin: 0;
        padding: 0;
        outline: none;
        transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
        user-select: none;
        -webkit-tap-highlight-color: transparent;
      }
      #swr-floating-btn:hover {
        transform: scale(1.08);
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.45);
      }
      #swr-floating-btn:active {
        transform: scale(0.96);
      }
      #swr-floating-btn.active {
        background: #2563eb;
        border-color: #60a5fa;
        box-shadow: 0 0 18px rgba(37, 99, 235, 0.6), 0 4px 14px rgba(0, 0, 0, 0.4);
      }
      #swr-floating-btn svg {
        width: 24px;
        height: 24px;
        fill: currentColor;
        pointer-events: none;
      }
      #swr-toast {
        position: fixed;
        top: 24px;
        right: 24px;
        background: rgba(15, 23, 42, 0.94);
        color: #f8fafc;
        padding: 10px 18px;
        border-radius: 8px;
        font-size: 13px;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
        font-weight: 500;
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.3);
        border: 1px solid #334155;
        z-index: 2147483647;
        opacity: 0;
        transform: translateY(-10px);
        transition: opacity 0.2s ease, transform 0.2s ease;
        pointer-events: none;
        box-sizing: border-box;
      }
      #swr-toast.show {
        opacity: 1;
        transform: translateY(0);
      }
      #swr-gdocs-btn {
        position: fixed;
        bottom: 82px;
        right: 24px;
        height: 38px;
        padding: 0 14px;
        border-radius: 20px;
        background: #0f172a;
        border: 2px solid #3b82f6;
        color: #f8fafc;
        box-shadow: 0 4px 14px rgba(0, 0, 0, 0.4);
        cursor: pointer;
        z-index: 2147483647;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        font-size: 12px;
        font-weight: 600;
        transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        user-select: none;
      }
      #swr-gdocs-btn:hover {
        background: #2563eb;
        transform: translateY(-2px);
        box-shadow: 0 6px 18px rgba(37, 99, 235, 0.5);
      }
      #swr-gdocs-btn svg {
        width: 16px;
        height: 16px;
        fill: currentColor;
      }
      .swr-tunnel-overlay {
        position: fixed;
        left: 0;
        right: 0;
        width: 100vw;
        pointer-events: none !important;
        z-index: 2147483640;
        background: rgba(15, 23, 42, 0.45);
        transition: height 0.12s ease-out;
        will-change: height;
        display: none;
      }
      #swr-tunnel-top {
        top: 0;
      }
      #swr-tunnel-bottom {
        bottom: 0;
      }
      .swr-confetti-particle {
        position: fixed;
        font-size: 26px;
        pointer-events: none;
        z-index: 2147483647;
        animation: swrFloatUp 2s cubic-bezier(0.2, 0.8, 0.3, 1) forwards;
      }
      @keyframes swrFloatUp {
        0% { opacity: 1; transform: translateY(0) scale(0.6) rotate(0deg); }
        50% { opacity: 1; transform: translateY(-75px) scale(1.2) rotate(20deg); }
        100% { opacity: 0; transform: translateY(-160px) scale(0.8) rotate(-20deg); }
      }
    `;
    (document.head || document.documentElement).appendChild(style);

    // Contenedor principal UI
    const root = document.createElement('div');
    root.id = 'swr-ui-root';
    root.className = 'swr-ui';
    root.setAttribute('data-swr-ui', 'true');

    // Overlays del Modo Túnel
    const tunnelTop = document.createElement('div');
    tunnelTop.id = 'swr-tunnel-top';
    tunnelTop.className = 'swr-tunnel-overlay';

    const tunnelBottom = document.createElement('div');
    tunnelBottom.id = 'swr-tunnel-bottom';
    tunnelBottom.className = 'swr-tunnel-overlay';

    root.appendChild(tunnelTop);
    root.appendChild(tunnelBottom);

    // Botón flotante
    floatingBtn = document.createElement('button');
    floatingBtn.id = 'swr-floating-btn';
    floatingBtn.title = t('floatingBtnTitle');
    floatingBtn.setAttribute('aria-label', 'Alternar modo lectura');
    floatingBtn.innerHTML = `
      <svg viewBox="0 0 24 24">
        <path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>
      </svg>
    `;
    floatingBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      toggleReader();
    });

    // Botón específico para Google Docs si aplica
    if (isGoogleDocs()) {
      const gdocsBtn = document.createElement('button');
      gdocsBtn.id = 'swr-gdocs-btn';
      gdocsBtn.title = t('gdocsBtnTitle');
      gdocsBtn.innerHTML = `
        <svg viewBox="0 0 24 24">
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
          <polyline points="14 2 14 8 20 8"></polyline>
          <line x1="16" y1="13" x2="8" y2="13"></line>
          <line x1="16" y1="17" x2="8" y2="17"></line>
        </svg>
        <span>Leer en Visor</span>
      `;
      gdocsBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        openGoogleDocInViewer();
      });
      root.appendChild(gdocsBtn);
    }

    // Toast
    toastEl = document.createElement('div');
    toastEl.id = 'swr-toast';

    root.appendChild(floatingBtn);
    root.appendChild(toastEl);
    document.body.appendChild(root);

    updateFloatingBtnStyle();
  }

  function updateFloatingBtnStyle() {
    if (floatingBtn) {
      if (config.enabled) {
        floatingBtn.classList.add('active');
      } else {
        floatingBtn.classList.remove('active');
      }
    }
  }

  // Notificación Toast de 1.5 segundos
  function showToast(message) {
    if (!toastEl) return;
    toastEl.textContent = message;
    toastEl.classList.add('show');
    if (toastTimer) {
      clearTimeout(toastTimer);
    }
    toastTimer = setTimeout(() => {
      if (toastEl) {
        toastEl.classList.remove('show');
      }
    }, 1500);
  }

  // 3. Tokenizador de palabras con TreeWalker
  function initTokenizer() {
    if (isInitialized) return;
    if (!document.body) return;

    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode: (node) => {
        const parent = node.parentElement;
        if (!parent) return NodeFilter.FILTER_REJECT;

        // Excluir etiquetas no deseadas y elementos de la extensión
        if (parent.closest(IGNORED_SELECTOR)) {
          return NodeFilter.FILTER_REJECT;
        }

        // Excluir nodos que ya hayan sido tokenizados
        if (parent.closest('.swr-word')) {
          return NodeFilter.FILTER_REJECT;
        }

        return node.nodeValue.trim().length > 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      }
    });

    const textNodes = [];
    while (walker.nextNode()) {
      textNodes.push(walker.currentNode);
    }

    for (let n = 0; n < textNodes.length; n++) {
      const node = textNodes[n];
      const text = node.nodeValue;
      if (!text) continue;

      const parts = text.split(/(\s+)/);
      const fragment = document.createDocumentFragment();

      for (let i = 0; i < parts.length; i++) {
        const part = parts[i];
        if (!part) continue;

        if (/\S/.test(part)) {
          const span = document.createElement('span');
          span.className = 'swr-word';
          span.dataset.swrIdx = words.length;
          span.dataset.rawWord = part;

          buildWordSpanContent(span, part, config.bionicAmount);

          words.push(span);
          fragment.appendChild(span);
        } else {
          fragment.appendChild(document.createTextNode(part));
        }
      }

      if (node.parentNode) {
        node.parentNode.replaceChild(fragment, node);
      }
    }

    // Aplicar BeeLine si está activo
    if (config.beelineEnabled) {
      applyBeeLine();
    }

    // Delegación de eventos eficiente: clic en cualquier palabra para cambiar el foco del color
    document.addEventListener('click', (e) => {
      const target = e.target.closest ? e.target.closest('.swr-word') : null;
      if (target) {
        e.preventDefault();
        e.stopPropagation();
        const idx = parseInt(target.dataset.swrIdx, 10);
        if (!isNaN(idx) && idx >= 0 && idx < words.length) {
          if (!config.enabled) {
            config.enabled = true;
            if (typeof chrome !== 'undefined' && chrome.storage?.sync) {
              chrome.storage.sync.set({ enabled: true });
            }
            enableReader();
          }
          currentIndex = idx;
          scrollAccumulator = 0;
          updateHighlight();
        }
      }
    }, true);

    // Si el usuario ya está desplazado en la página, iniciar en la primera palabra visible
    if (currentIndex === 0 && window.scrollY > 150) {
      currentIndex = findFirstVisibleWordIndex();
    }

    isInitialized = true;
  }

  // Estructurar el contenido de la palabra con Bionic Reading
  function buildWordSpanContent(span, rawPart, amount) {
    span.textContent = '';
    const match = rawPart.match(/^([^a-zA-Z0-9áéíóúÁÉÍÓÚñÑüÜ]*)([a-zA-Z0-9áéíóúÁÉÍÓÚñÑüÜ]+)(.*)$/);
    if (match) {
      const leadingPunct = match[1];
      const wordLetters = match[2];
      const trailing = match[3];

      if (wordLetters.length > 2) {
        const pct = parseInt(amount, 10) || 1;
        // Si pct <= 1: 1 sola letra; de lo contrario, porcentaje de la longitud de la palabra
        const fixLen = (pct <= 1)
          ? 1
          : Math.max(1, Math.min(wordLetters.length - 1, Math.ceil(wordLetters.length * (pct / 100))));

        const lead = wordLetters.substring(0, fixLen);
        const rest = wordLetters.substring(fixLen);

        if (leadingPunct) span.appendChild(document.createTextNode(leadingPunct));
        const leadSpan = document.createElement('span');
        leadSpan.className = 'swr-lead';
        leadSpan.textContent = lead;
        span.appendChild(leadSpan);
        if (rest || trailing) span.appendChild(document.createTextNode(rest + trailing));
        return;
      }
    }
    span.textContent = rawPart;
  }

  // Refrescar Bionic en todas las palabras cuando cambia bionicAmount
  function refreshBionicSpans() {
    const amount = parseInt(config.bionicAmount, 10) || 1;
    for (let i = 0; i < words.length; i++) {
      const span = words[i];
      const raw = span.dataset.rawWord;
      if (raw) {
        buildWordSpanContent(span, raw, amount);
      }
    }
  }

  // Conversión Hex a RGB
  function hexToRgb(hex) {
    if (!hex || typeof hex !== 'string') return { r: 37, g: 99, b: 235 };
    let c = hex.replace('#', '').trim();
    if (c.length === 3) c = c.split('').map(x => x + x).join('');
    if (c.length !== 6) return { r: 37, g: 99, b: 235 };
    return {
      r: parseInt(c.substring(0, 2), 16) || 0,
      g: parseInt(c.substring(2, 4), 16) || 0,
      b: parseInt(c.substring(4, 6), 16) || 0
    };
  }

  // Función BeeLine: gradiente continuo entre final y principio de líneas contiguas
  function applyBeeLine() {
    if (!words.length) return;

    if (!config.beelineEnabled) {
      if (beelineApplied) {
        for (let i = 0; i < words.length; i++) {
          words[i].style.color = '';
          delete words[i].dataset.beelineColor;
        }
        beelineApplied = false;
      }
      return;
    }

    const c1 = hexToRgb(config.beelineColor1 || '#2563eb');
    const c2 = hexToRgb(config.beelineColor2 || '#dc2626');
    const intensity = Math.max(0.1, Math.min(1, (parseInt(config.beelineIntensity, 10) || 60) / 100));

    // Agrupar palabras por su coordenada Y visual (líneas de texto)
    const lines = [];
    let currentLine = [];
    let lastY = null;

    for (let i = 0; i < words.length; i++) {
      const w = words[i];
      const rect = w.getBoundingClientRect();
      // Omitir palabras con tamaño 0 (ocultas)
      if (rect.width === 0 && rect.height === 0) continue;

      const y = Math.round(rect.top + window.scrollY);
      if (lastY === null || Math.abs(y - lastY) > 8) {
        if (currentLine.length) lines.push(currentLine);
        currentLine = [w];
        lastY = y;
      } else {
        currentLine.push(w);
      }
    }
    if (currentLine.length) lines.push(currentLine);

    // Asignar gradiente entre c1 y c2 a lo largo de cada línea
    for (let l = 0; l < lines.length; l++) {
      const lineWords = lines[l];
      const len = lineWords.length;
      for (let j = 0; j < len; j++) {
        const factor = len > 1 ? (j / (len - 1)) : 0.5;
        const start = (l % 2 === 0) ? c1 : c2;
        const end = (l % 2 === 0) ? c2 : c1;

        const r = Math.round(start.r + (end.r - start.r) * factor);
        const g = Math.round(start.g + (end.g - start.g) * factor);
        const b = Math.round(start.b + (end.b - start.b) * factor);

        const colorStr = `rgba(${r}, ${g}, ${b}, ${intensity})`;
        lineWords[j].dataset.beelineColor = colorStr;
        if (!lineWords[j].classList.contains('swr-active')) {
          lineWords[j].style.color = colorStr;
        }
      }
    }
    beelineApplied = true;
  }

  // 4. Activar y desactivar lector
  function enableReader() {
    initTokenizer();
    window.addEventListener('wheel', handleWheel, { passive: false, capture: true });
    updateHighlight();
    updateFloatingBtnStyle();
  }

  function disableReader() {
    window.removeEventListener('wheel', handleWheel, { passive: false, capture: true });
    clearLastHighlights();
    hideTunnel();
    updateFloatingBtnStyle();
  }

  // 5. Gestión del Modo Túnel (Focus Blur)
  function updateTunnel(activeWord) {
    const topEl = document.getElementById('swr-tunnel-top');
    const bottomEl = document.getElementById('swr-tunnel-bottom');
    if (!topEl || !bottomEl) return;

    if (!config.enabled || !config.tunnelEnabled || !activeWord) {
      hideTunnel();
      return;
    }

    const blurPx = Math.max(2, parseInt(config.tunnelBlur, 10) || 8);
    const filterVal = `blur(${blurPx}px)`;
    topEl.style.display = 'block';
    bottomEl.style.display = 'block';
    topEl.style.backdropFilter = filterVal;
    topEl.style.webkitBackdropFilter = filterVal;
    bottomEl.style.backdropFilter = filterVal;
    bottomEl.style.webkitBackdropFilter = filterVal;

    const rect = activeWord.getBoundingClientRect();
    const activeCenterY = rect.top + (rect.height / 2);
    const aperture = Math.max(60, parseInt(config.tunnelSize, 10) || 180);
    const halfAp = aperture / 2;

    const vh = window.innerHeight || document.documentElement.clientHeight;
    const topH = Math.max(0, activeCenterY - halfAp);
    const bottomH = Math.max(0, vh - (activeCenterY + halfAp));

    topEl.style.height = `${Math.round(topH)}px`;
    bottomEl.style.height = `${Math.round(bottomH)}px`;
  }

  function hideTunnel() {
    const topEl = document.getElementById('swr-tunnel-top');
    const bottomEl = document.getElementById('swr-tunnel-bottom');
    if (topEl) topEl.style.display = 'none';
    if (bottomEl) bottomEl.style.display = 'none';
  }

  // Felicitaciones por porcentaje en la lectura
  function checkProgressMilestone() {
    if (!config.celebrateEnabled || !words.length) return;
    const progressPct = Math.floor((currentIndex / (words.length - 1 || 1)) * 100);
    const step = Math.max(5, parseInt(config.celebrateStep, 10) || 25);
    const currentMilestone = Math.floor(progressPct / step) * step;

    if (currentMilestone > 0 && currentMilestone > lastCelebratedMilestone && currentMilestone <= 100) {
      lastCelebratedMilestone = currentMilestone;
      showToast(t('milestone', { step: currentMilestone }));
      triggerConfetti();
    }
  }

  // Efecto festivo de confeti con partículas CSS ligeras
  function triggerConfetti() {
    const emojis = ['🎉', '✨', '🌟', '🚀', '👏', '🎯'];
    const container = document.body || document.documentElement;
    const vh = window.innerHeight || 600;
    const vw = window.innerWidth || 800;

    for (let i = 0; i < 16; i++) {
      const p = document.createElement('span');
      p.className = 'swr-confetti-particle';
      p.textContent = emojis[Math.floor(Math.random() * emojis.length)];
      p.style.left = `${Math.floor(Math.random() * (vw - 60)) + 30}px`;
      p.style.top = `${Math.floor(Math.random() * (vh * 0.4)) + (vh * 0.3)}px`;
      container.appendChild(p);

      setTimeout(() => {
        p.remove();
      }, 2000);
    }
  }

  // Encontrar la primera palabra en el viewport
  function findFirstVisibleWordIndex() {
    const vh = window.innerHeight || document.documentElement.clientHeight;
    for (let i = 0; i < words.length; i++) {
      const rect = words[i].getBoundingClientRect();
      if (rect.top >= 40 && rect.bottom <= vh) {
        return i;
      }
    }
    return 0;
  }

  // 6. Limpiar resaltado previo en O(1)
  function clearLastHighlights() {
    for (let i = 0; i < lastHighlightedWords.length; i++) {
      const el = lastHighlightedWords[i];
      el.style.backgroundColor = '';
      el.style.color = el.dataset.beelineColor || '';
      el.style.outline = '';
      el.classList.remove('swr-active');
    }
    lastHighlightedWords = [];
  }

  // Contraste para legibilidad
  function getContrastColor(hexColor) {
    if (!hexColor || typeof hexColor !== 'string') return '#111827';
    let cleanHex = hexColor.replace('#', '').trim();
    if (cleanHex.length === 3) {
      cleanHex = cleanHex.split('').map(x => x + x).join('');
    }
    if (cleanHex.length !== 6) return '#111827';

    const r = parseInt(cleanHex.substring(0, 2), 16) || 0;
    const g = parseInt(cleanHex.substring(2, 4), 16) || 0;
    const b = parseInt(cleanHex.substring(4, 6), 16) || 0;
    const yiq = (r * 299 + g * 587 + b * 114) / 1000;
    return yiq >= 128 ? '#111827' : '#ffffff';
  }

  // 7. Resaltar palabras activas, auto-scroll y túnel
  function updateHighlight() {
    if (!words.length || !config.enabled) return;

    clearLastHighlights();

    const count = Math.max(1, parseInt(config.wordCount, 10) || 1);
    const bgColor = config.color || '#ffeb3b';
    const textColor = getContrastColor(bgColor);
    const isColorActive = config.colorHighlight !== false;

    for (let i = 0; i < count; i++) {
      const target = words[currentIndex + i];
      if (target) {
        if (isColorActive) {
          target.style.backgroundColor = bgColor;
          target.style.color = textColor;
          target.style.outline = '1px solid rgba(0, 0, 0, 0.15)';
        } else {
          // Recorrido con color apagado: borde enfocado sin color de fondo invasivo
          target.style.backgroundColor = 'transparent';
          target.style.color = target.dataset.beelineColor || '';
          target.style.outline = '2px solid ' + bgColor;
        }
        target.classList.add('swr-active');
        lastHighlightedWords.push(target);
      }
    }

    // Auto-scroll centrado suave enfocado en el centro del grupo subrayado
    const count = Math.max(1, parseInt(config.wordCount, 10) || 1);
    const activeWord = words[currentIndex + Math.floor((count - 1) / 2)] || words[currentIndex];
    if (activeWord) {
      if (config.scrollMode === 'center') {
        // Modo siempre centrado en el medio
        activeWord.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'nearest' });
      } else {
        // Margen natural (<18% o >82%)
        const rect = activeWord.getBoundingClientRect();
        const vh = window.innerHeight || document.documentElement.clientHeight;
        if (rect.top < vh * 0.18 || rect.bottom > vh * 0.82) {
          activeWord.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'nearest' });
        }
      }
      updateTunnel(activeWord);
    }

    checkProgressMilestone();
  }

  // 8. Control por rueda del ratón (Wheel Control - Ventana Deslizante Fluida)
  function handleWheel(e) {
    if (!config.enabled || !words.length) return;

    // Bloquear el scroll nativo de la página
    e.preventDefault();

    scrollAccumulator += e.deltaY;
    const threshold = Math.max(10, parseInt(config.sensitivity, 10) || 50);

    if (Math.abs(scrollAccumulator) >= threshold) {
      const steps = Math.trunc(scrollAccumulator / threshold);
      // Avanzar palabra por palabra (1 a 1) para un desplazamiento ultra-fluido en ventana deslizante
      const deltaWords = steps;

      const newIndex = Math.max(0, Math.min(words.length - 1, currentIndex + deltaWords));
      scrollAccumulator = scrollAccumulator % threshold;

      // Restablecer acumulador en los bordes para reactividad instantánea al cambiar de dirección
      if ((newIndex === 0 && steps < 0) || (newIndex === words.length - 1 && steps > 0)) {
        scrollAccumulator = 0;
      }

      if (newIndex !== currentIndex) {
        currentIndex = newIndex;
        updateHighlight();
      }
    }
  }

  // Escuchar scroll y resize para actualizar túnel y BeeLine
  window.addEventListener('scroll', () => {
    if (config.enabled && config.tunnelEnabled && words[currentIndex]) {
      updateTunnel(words[currentIndex]);
    }
  }, { passive: true });

  window.addEventListener('resize', () => {
    if (config.beelineEnabled) {
      applyBeeLine();
    }
    if (config.enabled && config.tunnelEnabled && words[currentIndex]) {
      updateTunnel(words[currentIndex]);
    }
  }, { passive: true });

  // Ejecutar cuando el DOM esté listo
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true });
  } else {
    init();
  }
})();
